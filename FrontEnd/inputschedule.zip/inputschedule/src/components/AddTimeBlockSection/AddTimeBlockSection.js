import './AddTimeBlockSection.css'

function AddTimeBlockSection() {
    return (
        <div className="addTimeBlockSection">
            <h1>Add a time block</h1>
        </div>
    );
}

export default AddTimeBlockSection;
