// ScheduleTitle.js

import './ScheduleTitle.css';

function ScheduleTitle() {
    return (
        <div className="scheduleTitle">
            <h1>Schedule</h1>
        </div>
    );
}

export default ScheduleTitle;
