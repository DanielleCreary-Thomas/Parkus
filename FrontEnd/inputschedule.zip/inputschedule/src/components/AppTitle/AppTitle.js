import './AppTitle.css'

function AppTitle() {
    return (
        <h1 className="appTitle">Parkus</h1>
    );
}

export default AppTitle;
