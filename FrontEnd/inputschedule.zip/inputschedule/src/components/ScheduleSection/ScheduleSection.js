import './ScheduleSection.css'
function ScheduleSection() {
    return (
        <div className="scheduleSectionContainer">
            <table className="scheduleSectionTable">
                <tbody>
                <tr>
                    <th>Monday</th>
                    <th>Tuesday</th>
                    <th>Wednesday</th>
                    <th>Thursday</th>
                    <th>Friday</th>
                </tr>
                </tbody>
                <tbody>
                <tr>
                    <td>Time Block</td>
                    <td>Time Block</td>
                    <td>Time Block</td>
                    <td>Time Block</td>
                    <td>Time Block</td>
                </tr>
                </tbody>
                <tbody>
                <tr>
                    <td>Time Block</td>
                    <td>Time Block</td>
                    <td>Time Block</td>
                    <td>Time Block</td>
                    <td>Time Block</td>
                </tr>
                </tbody>
                <tbody>
                <tr>
                    <td>Time Block</td>
                    <td>Time Block</td>
                    <td>Time Block</td>
                    <td>Time Block</td>
                    <td>Time Block</td>
                </tr>
                </tbody>
                <tbody>
                <tr>
                    <td>Time Block</td>
                    <td>Time Block</td>
                    <td>Time Block</td>
                    <td>Time Block</td>
                    <td>Time Block</td>
                </tr>
                </tbody>
                <tbody>
                <tr>
                    <td>Time Block</td>
                    <td>Time Block</td>
                    <td>Time Block</td>
                    <td>Time Block</td>
                    <td>Time Block</td>
                </tr>
                </tbody>
                <tbody>
                <tr>
                    <td>Time Block</td>
                    <td>Time Block</td>
                    <td>Time Block</td>
                    <td>Time Block</td>
                    <td>Time Block</td>
                </tr>
                </tbody>
                <tbody>
                <tr>
                    <td>Time Block</td>
                    <td>Time Block</td>
                    <td>Time Block</td>
                    <td>Time Block</td>
                    <td>Time Block</td>
                </tr>
                </tbody>
            </table>
        </div>
    );
}

export default ScheduleSection;
