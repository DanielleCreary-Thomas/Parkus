function Payment() {
    return <h1>Payment</h1>
}

export default Payment;