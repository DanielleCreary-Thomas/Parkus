function SpotSharing() {
    return <h1>SpotSharing</h1>
}

export default SpotSharing;